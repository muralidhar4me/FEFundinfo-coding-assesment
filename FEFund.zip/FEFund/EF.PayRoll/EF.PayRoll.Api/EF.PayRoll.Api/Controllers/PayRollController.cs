﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using FE.PayRoll.Business;
using FE.PayRoll.Business.Models;

namespace EF.PayRoll.Api.Controllers
{
   
    [ApiController]
    public class PayRollController : ControllerBase
    {
        private IPayrolls payRoll;
        public PayRollController(IPayrolls _payRolls)
        {
            payRoll = _payRolls;
        }

        // GET api/values
        [HttpGet]
 

        // GET api/values/5
        [HttpGet("/employee/{id}")]
        public  IEnumerable<EmployeeDetailModel> Get(int id)
        {
           return  payRoll.GetEmployeeById(id);

        }

        // POST api/values
        [HttpPost]
        public int Post([FromBody] EmployeeDetailModel employeeInfo)
        {
            var  resultCode = payRoll.AddEmployee(employeeInfo);
            return resultCode;
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
