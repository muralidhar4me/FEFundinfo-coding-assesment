﻿CREATE TABLE [dbo].[EmployeeInfo]
(
	[Id] INT NOT NULL PRIMARY KEY
)
