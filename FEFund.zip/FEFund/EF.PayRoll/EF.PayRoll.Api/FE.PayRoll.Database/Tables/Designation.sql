﻿CREATE TABLE [dbo].[Designation]
(
	[Id] INT NOT NULL PRIMARY KEY,
	Title VARCHAR(50) NOT NULL
)