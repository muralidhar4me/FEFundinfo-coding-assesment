﻿CREATE TABLE [dbo].[EmployeeType]
(
	[Id] INT NOT NULL PRIMARY KEY,
	EmployeeType VARCHAR(25) NOT NULL
)
