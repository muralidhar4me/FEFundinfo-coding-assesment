﻿CREATE TABLE [dbo].[EmployeeDetail]
(
	[Id] INT NOT NULL PRIMARY KEY,
	FirstName VARCHAR(250) NOT NULL,
	LastName VARCHAR(250) NOT NULL,
	Designation INT NOT NULL ,
	BasicSalary INT NOT NULL Default 0,
	EmployeeType INT NOT NULL, 
    CONSTRAINT [FK_EmployeeDetail_Designation] FOREIGN KEY ([Designation]) REFERENCES [Designation]([ID]), 
    CONSTRAINT [FK_EmployeeDetail_EmployeeType] FOREIGN KEY ([EmployeeType]) REFERENCES [EmployeeType]([ID])
)
