﻿using System.Collections.Generic;

using FE.PayRoll.Persistence;
using FE.PayRoll.Business.Models;


namespace FE.PayRoll.Business
{
    public interface IPayrolls
    {
        IEnumerable<EmployeeDetailModel> GetEmployeeById(int employeeId);
        int AddEmployee(EmployeeDetailModel employeeInfo);
    }
}
