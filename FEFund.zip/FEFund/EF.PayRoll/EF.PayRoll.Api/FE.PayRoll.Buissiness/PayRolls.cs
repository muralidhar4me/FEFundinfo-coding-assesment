﻿using System;
using System.Collections.Generic;
using System.Linq;



using FE.PayRoll.Persistence;
using FE.PayRoll.Business.Models;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using FE.PayRoll.Business;

namespace FE.PayRoll.Business
{
    public class PayRolls : IPayrolls
    {
        private PayRollDBContext dbContext;
  
        private Mapper mapper;
        public PayRolls(PayRollDBContext _dbContext, Mapper _mapper)
        {
            dbContext = _dbContext;
            mapper = _mapper;

        }
        public IEnumerable<EmployeeDetailModel> GetEmployeeById(int employeeId)
        {
            return dbContext.Employee.ProjectTo<EmployeeDetailModel>(mapper.ConfigurationProvider);
        }
        public int AddEmployee(EmployeeDetailModel employeeInfo)
        {
            var employeeinfo = mapper.Map<EmployeeDetailEntity>(employeeInfo);
            dbContext.Add(employeeinfo);
            return dbContext.SaveChanges();
        }
    }
}
