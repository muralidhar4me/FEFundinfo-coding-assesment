﻿

namespace FE.PayRoll.Business.Models
{
    public class EmployeeDetailModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Designation { get; set; }
        public string EmloyeeType { get; set; }
        public int BasicSalary { get; set; }
        public decimal Salary { get; set; }
    }
}
