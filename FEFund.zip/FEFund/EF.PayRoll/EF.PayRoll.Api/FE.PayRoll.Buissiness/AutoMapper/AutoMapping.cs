﻿using AutoMapper;
using FE.PayRoll.Persistence;
using FE.PayRoll.Business.Models;

namespace FE.PayRoll.Business.AutoMapper
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            CreateMap<EmployeeDetailEntity, EmployeeDetailModel>()
                 .ForMember(dest => dest.EmloyeeType, conf => conf.MapFrom(src => src.EmployeeTypes.EmployeeType))
                 .ForMember(dest => dest.Designation, conf => conf.MapFrom(src => src.Designations.Title));

            CreateMap<EmployeeDetailEntity, EmployeeDetailModel>().ReverseMap();
        }
    }
}