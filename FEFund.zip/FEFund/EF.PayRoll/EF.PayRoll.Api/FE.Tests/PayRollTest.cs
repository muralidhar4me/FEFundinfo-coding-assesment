﻿using System;
using System.Data.SQLite;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using Xunit;
using AutoMapper;

using FE.PayRoll.Business;
using FE.PayRoll.Business.Models;
using FE.PayRoll.Business.AutoMapper;
using FE.PayRoll.Persistence;


namespace FE.Tests
{
    public class PayRollTest
    {
        [Fact]
        public void Test_Get_Employee_Result()
        {
            MapperConfiguration mapConfig = new MapperConfiguration(cfg =>
           {
               cfg.AddProfile(new AutoMapping());
           });
            var mockMapper = new Mapper(mapConfig);



            // In-memory database only exists while the connection is open
            var connection = new SQLiteConnection("DataSource=:memory:");

            connection.Open();

            var options = new DbContextOptionsBuilder<PayRollDBContext>()
               .Options;

            PayRollDBContext dBContext = new PayRollDBContext(options);
            PayRollSeedData seedData = new PayRollSeedData(dBContext);
            seedData.SeedData();
            IPayrolls payRoll = new PayRolls(dBContext, mockMapper);
            
            var employee1= payRoll.GetEmployeeById(1);



        }
    }
}
