﻿using System;
using System.Collections.Generic;
using Xunit;

using FE.PayRoll.Business;
using FE.PayRoll.Business.Models;
using FE.PayRoll.Business.AutoMapper;
using FE.PayRoll.Persistence;

namespace FE.Tests
{
    public class PayRollSeedData
    {
        public readonly PayRollDBContext dbContext;

        public PayRollSeedData(PayRollDBContext _dbContext)
        {
            dbContext = _dbContext;
        }

        public void SeedData()
        {
            DesignationEntity architect = new DesignationEntity() { Id = 1, Title = "Architect" };
            DesignationEntity manager = new DesignationEntity() { Id = 2, Title = "Manager" };

            dbContext.AddRange(manager, architect);
            dbContext.SaveChanges();

            EmployeeTypeEntity contract = new EmployeeTypeEntity() { Id = 1, EmployeeType = "Contract" };
            EmployeeTypeEntity permanent = new EmployeeTypeEntity() { Id = 1, EmployeeType = "Permanent" };
            dbContext.AddRange(contract, permanent);
            dbContext.SaveChanges();

            EmployeeDetailEntity empRecord1 = new EmployeeDetailEntity()
            {
                Id = 1,
                FirstName = "Employe-1 FirstName",
                LastName = "Employee-1 LastName",
                BasicSalary = 1000,
                EmployeeTypes = dbContext.EmployeeType.Find(1),
                Designations = dbContext.Designation.Find(1)
            };

            EmployeeDetailEntity empRecord2 = new EmployeeDetailEntity()
            {
                Id = 1,
                FirstName = "Employe-2 FirstName",
                LastName = "Employee-2 LastName",
                BasicSalary = 2000,
                EmployeeTypes = dbContext.EmployeeType.Find(2),
                Designations = dbContext.Designation.Find(2)
            };

            dbContext.AddRange(empRecord1, empRecord2);
            dbContext.SaveChanges();
        }
    }
}
