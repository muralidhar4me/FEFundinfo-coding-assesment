﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FE.PayRoll.Persistence
{
    public class EmployeeDetailEntity
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int BasicSalary { get; set; }
        public int Designation { get; set; }
        public int EmployeeType { get; set; }

        public virtual DesignationEntity Designations { get; set; }

        public virtual EmployeeTypeEntity EmployeeTypes { get; set; }
    }
}
