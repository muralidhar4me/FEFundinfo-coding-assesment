﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FE.PayRoll.Persistence
{
    public class DesignationEntity
    {
        public int Id { get; set; }
        public string Title { get; set; }

    }
}
