﻿using System;
using Microsoft.EntityFrameworkCore;

namespace FE.PayRoll.Persistence
{
    public class PayRollDBContext : DbContext
    {
        public PayRollDBContext(DbContextOptions<PayRollDBContext> options) : base(options)
        {
        }
        public DbSet<EmployeeDetailEntity> Employee { get; set; }
        public DbSet<DesignationEntity> Designation { get; set; }
        public DbSet<EmployeeTypeEntity> EmployeeType { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<EmployeeDetailEntity>(entity =>
                {
                    entity.HasKey(e => e.Id);
                    entity.Property(e => e.FirstName);
                    entity.Property(e => e.LastName);
                    entity.HasOne(d => d.Designations);
                    entity.HasOne(d => d.EmployeeTypes);
                });
            modelBuilder.Entity<DesignationEntity>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Title);

            });
            modelBuilder.Entity<EmployeeTypeEntity>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.EmployeeType);

            });
        }
    }
}
