﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FE.PayRoll.Persistence
{
    public class EmployeeTypeEntity
    {
        public int Id { get; set; }
        public string EmployeeType { get; set; }

    }
}
